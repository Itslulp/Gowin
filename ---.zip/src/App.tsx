import { useEffect, useMemo, useRef, useState, useCallback } from "react";

type Question = {
  emoji: string;
  question: string;
  options: string[];
  answer: string;
};

type LeaderboardEntry = {
  name: string;
  time: number;
  lives: number;
  timestamp: number;
};

type GoatRecord = {
  name: string;
  time: number;
  lives: number;
  timestamp: number;
};

const isBetterRecord = (candidate: GoatRecord, current: GoatRecord | null) => {
  if (!current) return true;
  if (candidate.lives !== current.lives) return candidate.lives > current.lives;
  return candidate.time < current.time;
};

type Match = {
  player1: string;
  player2: string;
  winner?: string;
  player1Lives?: number;
  player2Lives?: number;
  player1Time?: number;
  player2Time?: number;
};

type TournamentRound = {
  roundNumber: number;
  matches: Match[];
  questions: Question[];
};

type ChatMessage = {
  sender: string;
  message: string;
  timestamp: number;
};

type MultiplayerRoom = {
  roomId: string;
  mode: "cooperative" | "versus";
  player1: string;
  player2?: string;
  player1Ready: boolean;
  player2Ready: boolean;
  chat: ChatMessage[];
  currentQuestion: number;
  player1Lives: number;
  player2Lives: number;
  player1Time: number;
  player2Time: number;
  startTime?: number;
  status: "waiting" | "playing" | "finished";
  winner?: string;
};

const allQuestionsAr: Question[][] = [
  [
    { emoji: "🌍", question: "ما هي عاصمة فرنسا؟", options: ["باريس", "مدريد", "روما", "برلين"], answer: "باريس" },
    { emoji: "🧮", question: "كم الناتج؟ 12 × 8", options: ["92", "96", "88", "108"], answer: "96" },
    { emoji: "🪐", question: "أكبر كوكب في المجموعة الشمسية؟", options: ["الأرض", "المشتري", "المريخ", "زحل"], answer: "المشتري" },
    { emoji: "💻", question: "مؤسس شركة مايكروسوفت؟", options: ["ستيف جوبز", "إيلون ماسك", "بيل غيتس", "مارك زوكربيرغ"], answer: "بيل غيتس" },
  ],
  [
    { emoji: "🏔️", question: "أعلى جبل في العالم؟", options: ["كليمنجارو", "إيفرست", "الألب", "الأنديز"], answer: "إيفرست" },
    { emoji: "🔢", question: "كم الناتج؟ 15 × 7", options: ["95", "100", "105", "110"], answer: "105" },
    { emoji: "🌊", question: "أكبر محيط في العالم؟", options: ["الأطلسي", "الهندي", "الهادئ", "المتجمد"], answer: "الهادئ" },
    { emoji: "🎨", question: "رسام لوحة الموناليزا؟", options: ["بيكاسو", "دافنشي", "فان جوخ", "مونيه"], answer: "دافنشي" },
  ],
  [
    { emoji: "⚽", question: "أكثر دولة فازت بكأس العالم؟", options: ["البرازيل", "ألمانيا", "الأرجنتين", "إيطاليا"], answer: "البرازيل" },
    { emoji: "🧪", question: "الرمز الكيميائي للذهب؟", options: ["Go", "Gd", "Au", "Ag"], answer: "Au" },
    { emoji: "📅", question: "عدد أيام السنة الكبيسة؟", options: ["365", "366", "364", "367"], answer: "366" },
    { emoji: "🌡️", question: "درجة غليان الماء؟", options: ["90°", "100°", "110°", "120°"], answer: "100°" },
  ],
];

const allQuestionsEn: Question[][] = [
  [
    { emoji: "🌍", question: "What is the capital of France?", options: ["Paris", "Madrid", "Rome", "Berlin"], answer: "Paris" },
    { emoji: "🧮", question: "What is 12 × 8?", options: ["92", "96", "88", "108"], answer: "96" },
    { emoji: "🪐", question: "The largest planet in our solar system?", options: ["Earth", "Jupiter", "Mars", "Saturn"], answer: "Jupiter" },
    { emoji: "💻", question: "Founder of Microsoft?", options: ["Steve Jobs", "Elon Musk", "Bill Gates", "Mark Zuckerberg"], answer: "Bill Gates" },
  ],
  [
    { emoji: "🏔️", question: "The highest mountain in the world?", options: ["Kilimanjaro", "Everest", "The Alps", "The Andes"], answer: "Everest" },
    { emoji: "🔢", question: "What is 15 × 7?", options: ["95", "100", "105", "110"], answer: "105" },
    { emoji: "🌊", question: "The largest ocean in the world?", options: ["Atlantic", "Indian", "Pacific", "Arctic"], answer: "Pacific" },
    { emoji: "🎨", question: "Who painted the Mona Lisa?", options: ["Picasso", "Da Vinci", "Van Gogh", "Monet"], answer: "Da Vinci" },
  ],
  [
    { emoji: "⚽", question: "Which country won the most FIFA World Cups?", options: ["Brazil", "Germany", "Argentina", "Italy"], answer: "Brazil" },
    { emoji: "🧪", question: "The chemical symbol for gold?", options: ["Go", "Gd", "Au", "Ag"], answer: "Au" },
    { emoji: "📅", question: "How many days in a leap year?", options: ["365", "366", "364", "367"], answer: "366" },
    { emoji: "🌡️", question: "Boiling point of water?", options: ["90°", "100°", "110°", "120°"], answer: "100°" },
  ],
];

const TOTAL_LIVES = 5;
const PLAYER_KEY = "player-name";
const LEADERBOARD_KEY = "gowin-leaderboard";
const TOURNAMENT_KEY = "gowin-tournament";
const GOAT_KEY = "gowin-goat-record";
const MULTIPLAYER_ROOMS_KEY = "gowin-multiplayer-rooms";

const getRankTitle = (rank: number): { title: string; emoji: string; color: string } => {
  if (rank === 1) return { title: "أسطورة", emoji: "👑", color: "from-yellow-400 to-orange-500" };
  if (rank === 2) return { title: "عبقري", emoji: "🧠", color: "from-purple-400 to-pink-500" };
  if (rank === 3) return { title: "ذيب", emoji: "🐺", color: "from-blue-400 to-cyan-500" };
  if (rank <= 5) return { title: "محترف", emoji: "⭐", color: "from-green-400 to-emerald-500" };
  if (rank <= 8) return { title: "متقدم", emoji: "🎯", color: "from-indigo-400 to-blue-500" };
  if (rank <= 12) return { title: "نجم", emoji: "✨", color: "from-pink-400 to-rose-500" };
  if (rank <= 16) return { title: "صاعد", emoji: "🚀", color: "from-cyan-400 to-teal-500" };
  return { title: "مبتدئ", emoji: "🔥", color: "from-gray-400 to-slate-500" };
};

const useAudio = () => {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // إنشاء عنصر صوتي مخفي لتشغيل أصوات تفاعلية بسيطة
  useEffect(() => {
    if (typeof window !== "undefined") {
      audioRef.current = new Audio();
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const playSound = (frequency: number, duration: number = 0.5, volume: number = 0.5) => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = "sine";
      osc.frequency.value = frequency;
      
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.05);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
      
      setTimeout(() => ctx.close(), (duration + 0.1) * 1000);
    } catch (e) {}
  };

  const playCorrect = () => {
    playSound(523.25, 0.3, 0.3);
    setTimeout(() => playSound(659.25, 0.3, 0.3), 100);
    setTimeout(() => playSound(783.99, 0.4, 0.3), 200);
  };

  const playWrong = () => {
    playSound(196.00, 0.5, 0.3);
  };

  const playFanfare = () => {
    const notes = [523.25, 659.25, 783.99, 1046.50];
    notes.forEach((note, i) => {
      setTimeout(() => playSound(note, 0.6, 0.4), i * 150);
    });
  };

  const playExciting = () => {
    playSound(392.00, 0.3, 0.3);
    setTimeout(() => playSound(493.88, 0.3, 0.3), 50);
    setTimeout(() => playSound(587.33, 0.4, 0.3), 100);
  };

  const playStart = () => {
    playSound(523.25, 0.5, 0.4);
    setTimeout(() => playSound(659.25, 0.5, 0.4), 150);
    setTimeout(() => playSound(783.99, 0.6, 0.4), 300);
  };

  const playQuestionSound = () => {
    playSound(440, 0.2, 0.25);
    setTimeout(() => playSound(554.37, 0.2, 0.25), 100);
  };

  const playLoseLife = () => {
    playSound(329.63, 0.4, 0.3);
    setTimeout(() => playSound(293.66, 0.5, 0.25), 150);
    setTimeout(() => playSound(261.63, 0.6, 0.2), 300);
  };

  const playVictoryMusic = () => {
    const melody = [523.25, 659.25, 783.99, 1046.50, 783.99, 1046.50];
    melody.forEach((note, i) => {
      setTimeout(() => playSound(note, 0.5, 0.4), i * 200);
    });
  };

  const playClick = () => {
    playSound(800, 0.08, 0.2);
  };

  return { 
    playCorrect, 
    playWrong, 
    playFanfare, 
    playExciting, 
    playStart,
    playQuestionSound,
    playLoseLife,
    playVictoryMusic,
    playClick
  };
};

 

export function App() {
  const [playerName, setPlayerName] = useState("");
  const [playerInput, setPlayerInput] = useState("");
  const [current, setCurrent] = useState(0);
  const [lives, setLives] = useState(TOTAL_LIVES);
  const [shake, setShake] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [status, setStatus] = useState<"playing" | "won" | "lost">("playing");
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [goatRecord, setGoatRecord] = useState<GoatRecord | null>(null);
  const [activeTab, setActiveTab] = useState<"leaderboard" | "tournament" | "challenge">("leaderboard");
  const [tournament, setTournament] = useState<TournamentRound[]>([]);
  const [language, setLanguage] = useState<"ar" | "en">("ar");
  const [tournamentStarted, setTournamentStarted] = useState(false);
  
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareLink, setShareLink] = useState("");
  const [multiplayerRoom, setMultiplayerRoom] = useState<MultiplayerRoom | null>(null);
  const [rooms, setRooms] = useState<MultiplayerRoom[]>([]);

  const { 
    playCorrect, 
    playWrong, 
    playFanfare, 
    playExciting, 
    playStart,
    playQuestionSound,
    playLoseLife,
    playVictoryMusic,
    playClick
  } = useAudio();

  const questions = language === "ar" ? allQuestionsAr[0] : allQuestionsEn[0];
  
  const generateTournament = useCallback((leaderboard: LeaderboardEntry[]): TournamentRound[] => {
    if (leaderboard.length < 4) return [];
    
    const top4 = leaderboard.slice(0, 4);
    const rounds: TournamentRound[] = [];
    let currentPlayers = top4.map(e => e.name);
    let roundNumber = 1;
    let questionSetIndex = 0;

    while (currentPlayers.length > 1) {
      const matches: Match[] = [];
      const nextPlayers: string[] = [];

      for (let i = 0; i < currentPlayers.length; i += 2) {
        if (i + 1 < currentPlayers.length) {
          const player1 = currentPlayers[i];
          const player2 = currentPlayers[i + 1];
          
          const p1Entry = leaderboard.find(e => e.name === player1);
          const p2Entry = leaderboard.find(e => e.name === player2);
          
          const p1Score = (p1Entry?.lives || 0) * 100 - (p1Entry?.time || 100);
          const p2Score = (p2Entry?.lives || 0) * 100 - (p2Entry?.time || 100);
          
          const winner = p1Score >= p2Score ? player1 : player2;
          
          matches.push({
            player1,
            player2,
            winner,
            player1Lives: p1Entry?.lives,
            player2Lives: p2Entry?.lives,
            player1Time: p1Entry?.time,
            player2Time: p2Entry?.time,
          });
          
          nextPlayers.push(winner);
        } else {
          nextPlayers.push(currentPlayers[i]);
        }
      }

      // استخدام أسئلة اللغة المختارة
      const questionSets = language === "ar" ? allQuestionsAr : allQuestionsEn;
      const questionsForRound = questionSetIndex < questionSets.length 
        ? questionSets[questionSetIndex] 
        : questionSets[0];
      
      rounds.push({
        roundNumber,
        matches,
        questions: questionsForRound,
      });

      currentPlayers = nextPlayers;
      roundNumber++;
      questionSetIndex++;
    }

    return rounds;
  }, [language]);

  const [youtubeMusicStarted, setYoutubeMusicStarted] = useState(false);

  // تشغيل موسيقى YouTube عند أول لمسة للشاشة
  useEffect(() => {
    const handleInitialTouch = () => {
      if (!youtubeMusicStarted) {
        setYoutubeMusicStarted(true);
      }
    };
    window.addEventListener('touchstart', handleInitialTouch, { once: true });
    window.addEventListener('mousedown', handleInitialTouch, { once: true });
    return () => {
      window.removeEventListener('touchstart', handleInitialTouch);
      window.removeEventListener('mousedown', handleInitialTouch);
    };
  }, []);

  useEffect(() => {
    const storedName = localStorage.getItem(PLAYER_KEY);
    const storedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    const storedTournament = localStorage.getItem(TOURNAMENT_KEY);
    const storedGoat = localStorage.getItem(GOAT_KEY);
    const storedRooms = localStorage.getItem(MULTIPLAYER_ROOMS_KEY);
    const storedTournamentStarted = localStorage.getItem("gowin-tournament-started");
    
    if (storedName) {
      setPlayerName(storedName);
      setPlayerInput(storedName);
    }
    if (storedLeaderboard) {
      const lb = JSON.parse(storedLeaderboard);
      setLeaderboard(lb);
      // لا نبدأ الدوري تلقائياً
    }
    if (storedTournament) {
      setTournament(JSON.parse(storedTournament));
    }
    if (storedGoat) {
      setGoatRecord(JSON.parse(storedGoat));
    }
    if (storedRooms) {
      setRooms(JSON.parse(storedRooms));
    }
    if (storedTournamentStarted) {
      setTournamentStarted(JSON.parse(storedTournamentStarted));
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const storedRooms = localStorage.getItem(MULTIPLAYER_ROOMS_KEY);
      if (storedRooms) {
        const parsedRooms = JSON.parse(storedRooms);
        setRooms(parsedRooms);
        
        if (multiplayerRoom) {
          const currentRoom = parsedRooms.find((r: MultiplayerRoom) => r.roomId === multiplayerRoom.roomId);
          if (currentRoom) {
            setMultiplayerRoom(currentRoom);
          }
        }
      }
    }, 1000);
    
    return () => clearInterval(interval);
  }, [multiplayerRoom]);

  useEffect(() => {
    if (!playerName || status !== "playing") return;
    const timer = window.setInterval(() => setElapsed((prev) => prev + 1), 1000);
    return () => window.clearInterval(timer);
  }, [playerName, status]);

  useEffect(() => {
    if (playerName && status === "playing") {
      playQuestionSound();
    }
  }, [current, playerName, status]);

  

  // لا حاجة لموسيقى الخلفية من Web Audio - نستخدم YouTube بدلاً من ذلك

  const question = questions[current];
  const progress = useMemo(() => ((current + 1) / questions.length) * 100, [current]);

  const handleStart = () => {
    if (!playerInput.trim()) return;
    playStart();
    localStorage.setItem(PLAYER_KEY, playerInput.trim());
    setPlayerName(playerInput.trim());
  };

  const finishGame = (nextStatus: "won" | "lost") => {
    setStatus(nextStatus);
    if (nextStatus === "won") {
      playFanfare();
      playVictoryMusic();
      const newEntry: LeaderboardEntry = {
        name: playerName,
        time: elapsed,
        lives,
        timestamp: Date.now(),
      };
      const updatedLeaderboard = [...leaderboard, newEntry]
        .sort((a, b) => {
          if (a.lives !== b.lives) return b.lives - a.lives;
          return a.time - b.time;
        })
        .slice(0, 4);

      setLeaderboard(updatedLeaderboard);
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(updatedLeaderboard));

      // لا نبدأ الدوري تلقائياً، ننتظر الضغط على زر "ابدأ الدوري"
      // فقط نعدّد اللاعبين حتى يصلوا إلى 4
    }
  };

  const startTournament = () => {
    if (leaderboard.length < 4) return;
    const tourney = generateTournament(leaderboard);
    setTournament(tourney);
    setTournamentStarted(true);
    localStorage.setItem(TOURNAMENT_KEY, JSON.stringify(tourney));
    localStorage.setItem("gowin-tournament-started", JSON.stringify(true));
    playExciting();
    
    // تحديث THE GOAT إذا كان هناك فائز
    if (tourney.length > 0) {
      const finalRound = tourney[tourney.length - 1];
      const finalWinner = finalRound.matches[0]?.winner;
      if (finalWinner) {
        const winnerEntry = leaderboard.find((entry) => entry.name === finalWinner);
        if (winnerEntry) {
          const candidate: GoatRecord = {
            name: finalWinner,
            time: winnerEntry.time,
            lives: winnerEntry.lives,
            timestamp: Date.now(),
          };
          if (isBetterRecord(candidate, goatRecord)) {
            setGoatRecord(candidate);
            localStorage.setItem(GOAT_KEY, JSON.stringify(candidate));
          }
        }
      }
    }
  };

  const handleAnswer = (option: string) => {
    if (status !== "playing") return;
    if (option === question.answer) {
      playCorrect();
      playClick();
      if (current === questions.length - 1) {
        finishGame("won");
      } else {
        setCurrent((prev) => prev + 1);
      }
    } else {
      setShake(true);
      playWrong();
      playLoseLife();
      playClick();
      navigator.vibrate?.(250);
      setLives((prev) => {
        const updated = prev - 1;
        if (updated <= 0) {
          finishGame("lost");
        }
        return updated;
      });
      if (current < questions.length - 1) {
        setCurrent((prev) => prev + 1);
      }
    }

    window.setTimeout(() => {
      setShake(false);
    }, 700);
  };

  

  const hearts = Array.from({ length: TOTAL_LIVES }).map((_, index) => index < lives);

  const createRoom = (mode: "cooperative" | "versus") => {
    const roomId = Math.random().toString(36).substring(2, 9);
    const newRoom: MultiplayerRoom = {
      roomId,
      mode,
      player1: playerName,
      player1Ready: false,
      player2Ready: false,
      chat: [],
      currentQuestion: 0,
      player1Lives: TOTAL_LIVES,
      player2Lives: TOTAL_LIVES,
      player1Time: 0,
      player2Time: 0,
      status: "waiting",
    };
    
    const updatedRooms = [...rooms, newRoom];
    setRooms(updatedRooms);
    localStorage.setItem(MULTIPLAYER_ROOMS_KEY, JSON.stringify(updatedRooms));
    setMultiplayerRoom(newRoom);
    
    const link = `${window.location.origin}?room=${roomId}`;
    setShareLink(link);
    setShowShareModal(true);
    playExciting();
  };

  const joinRoom = (roomId: string) => {
    const room = rooms.find(r => r.roomId === roomId);
    if (room && !room.player2) {
      const updatedRoom = { ...room, player2: playerName };
      const updatedRooms = rooms.map(r => r.roomId === roomId ? updatedRoom : r);
      setRooms(updatedRooms);
      localStorage.setItem(MULTIPLAYER_ROOMS_KEY, JSON.stringify(updatedRooms));
      setMultiplayerRoom(updatedRoom);
      playExciting();
    }
  };

  const toggleReady = () => {
    if (!multiplayerRoom) return;
    
    const isPlayer1 = multiplayerRoom.player1 === playerName;
    const updatedRoom = {
      ...multiplayerRoom,
      player1Ready: isPlayer1 ? !multiplayerRoom.player1Ready : multiplayerRoom.player1Ready,
      player2Ready: !isPlayer1 ? !multiplayerRoom.player2Ready : multiplayerRoom.player2Ready,
    };
    
    if (updatedRoom.player1Ready && updatedRoom.player2Ready && updatedRoom.status === "waiting") {
      updatedRoom.status = "playing";
      updatedRoom.startTime = Date.now();
    }
    
    const updatedRooms = rooms.map(r => r.roomId === multiplayerRoom.roomId ? updatedRoom : r);
    setRooms(updatedRooms);
    localStorage.setItem(MULTIPLAYER_ROOMS_KEY, JSON.stringify(updatedRooms));
    setMultiplayerRoom(updatedRoom);
  };

  const leaveRoom = () => {
    if (!multiplayerRoom) return;
    
    const updatedRooms = rooms.filter(r => r.roomId !== multiplayerRoom.roomId);
    setRooms(updatedRooms);
    localStorage.setItem(MULTIPLAYER_ROOMS_KEY, JSON.stringify(updatedRooms));
    setMultiplayerRoom(null);
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const roomId = params.get("room");
    if (roomId && playerName) {
      joinRoom(roomId);
      setActiveTab("challenge");
    }
  }, [playerName]);

  return (
    <div
      className="min-h-screen bg-animated-gradient text-white"
      onPointerDown={() => {
        // تشغيل موسيقى YouTube عند التفاعل
        if (!youtubeMusicStarted) {
          setYoutubeMusicStarted(true);
        }
      }}
    >
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col gap-10 px-6 py-10">
        <header className="flex flex-wrap items-center justify-between gap-6">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 blur-2xl opacity-50 animate-pulse"></div>
            <div className="relative">
              <div className="flex items-center gap-3">
                <span className="text-5xl animate-bounce" style={{ animationDuration: '2s' }}>🏆</span>
                <div>
                  <h1 className="text-4xl md:text-5xl font-black bg-gradient-to-r from-yellow-200 via-yellow-300 to-orange-400 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(251,191,36,0.7)]" style={{ textShadow: '0 0 40px rgba(251, 191, 36, 0.5)' }}>
                    دوري أبطال Gowin
                  </h1>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="h-1 w-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full"></div>
                    <p className="text-xs md:text-sm text-white/80 font-medium">⚔️ ساحة الأبطال والتحديات ⚔️</p>
                    <div className="h-1 w-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-full"></div>
                  </div>
                </div>
                <span className="text-5xl animate-bounce" style={{ animationDuration: '2s', animationDelay: '0.5s' }}>🏆</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
              className="rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 px-4 py-2 text-sm font-bold text-slate-900 transition hover:scale-105 shadow-lg"
            >
              {language === "ar" ? "EN 🌍" : "AR 🇸🇦"}
            </button>
            <div className="text-right">
              <p className="text-sm text-white/70">{language === "ar" ? "الوقت" : "Time"}</p>
              <p className="text-2xl font-semibold">{elapsed}s</p>
            </div>
            <div>
              <p className="text-sm text-white/70">{language === "ar" ? "الحيوات" : "Lives"}</p>
              <div className="flex gap-1">
                {hearts.map((filled, index) => (
                  <span key={index} className={`text-xl ${filled ? "" : "opacity-30"}`}>
                    ❤️
                  </span>
                ))}
              </div>
            </div>
          </div>
        </header>

        <main className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
          <section
            className={`relative rounded-3xl border border-white/15 bg-white/10 p-8 shadow-xl backdrop-blur transition-transform ${
              shake ? "card-shake" : ""
            }`}
          >
            <div className="absolute inset-x-8 top-6 h-2 rounded-full bg-white/10">
              <div
                className="h-2 rounded-full bg-gradient-to-r from-emerald-300 via-sky-300 to-indigo-300 transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="pt-8">
              {status === "playing" ? (
                <>
                  <p className="text-sm text-white/70">{language === "ar" ? `السؤال ${current + 1} / ${questions.length}` : `Question ${current + 1} / ${questions.length}`}</p>
                  <div className="mt-3 flex items-start gap-4">
                    <span className="text-6xl">{question.emoji}</span>
                    <h2 className="text-2xl font-semibold leading-relaxed flex-1">{question.question}</h2>
                  </div>
                  <div className="mt-6 grid gap-3">
                    {question.options.map((option) => (
                      <button
                        key={option}
                        onClick={() => handleAnswer(option)}
                        className="rounded-2xl border border-white/20 bg-white/10 px-6 py-3 text-right text-lg font-medium transition hover:-translate-y-1 hover:border-white/50 hover:bg-white/20 hover:shadow-lg"
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </>
              ) : (
                <div className="rounded-2xl border border-white/20 bg-black/30 p-6 text-center">
                  <h3 className="text-2xl font-semibold mb-2">
                    {status === "won"
                      ? language === "ar"
                        ? "🎉 تم إدخالك في الدوري"
                        : "🎉 You have been entered into the league"
                      : language === "ar"
                      ? "انتهت المحاولة 😢"
                      : "Game Over 😢"}
                  </h3>
                  <p className="mt-1 text-white/70">
                    {language === "ar"
                      ? `وقتك النهائي: ${elapsed}s`
                      : `Your final time: ${elapsed}s`}
                  </p>
                  {status === "won" && (
                    <p className="mt-4 text-sm text-emerald-300">
                      {language === "ar"
                        ? "انتظر نتائج باقي اللاعبين وشاهد ترتيبك في لوحة الشرف ودوري الأبطال."
                        : "Wait for other players and check your position in the leaderboard and champions league."}
                    </p>
                  )}
                </div>
              )}
            </div>
          </section>

          <section className="flex flex-col gap-6">
            <div className="rounded-3xl border border-white/15 bg-white/10 p-6 shadow-xl backdrop-blur">
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setActiveTab("leaderboard")}
                  className={`flex-1 rounded-xl px-3 py-2 text-sm font-semibold transition ${
                    activeTab === "leaderboard"
                      ? "bg-gradient-to-r from-yellow-400 to-orange-500 text-slate-900 shadow-lg"
                      : "bg-white/10 text-white/70 hover:bg-white/20"
                  }`}
                >
                  🏆 {language === "ar" ? "المتصدرين" : "Leaderboard"}
                </button>
                <button
                  onClick={() => setActiveTab("tournament")}
                  className={`flex-1 rounded-xl px-3 py-2 text-sm font-semibold transition ${
                    activeTab === "tournament"
                      ? "bg-gradient-to-r from-purple-400 to-pink-500 text-slate-900 shadow-lg"
                      : "bg-white/10 text-white/70 hover:bg-white/20"
                  }`}
                >
                  ⚔️ {language === "ar" ? "الدوري" : "Tournament"}
                </button>
                <button
                  onClick={() => setActiveTab("challenge")}
                  className={`flex-1 rounded-xl px-3 py-2 text-sm font-semibold transition ${
                    activeTab === "challenge"
                      ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-900 shadow-lg"
                      : "bg-white/10 text-white/70 hover:bg-white/20"
                  }`}
                >
                  🎮 {language === "ar" ? "تحدي صديق" : "Challenge"}
                </button>
              </div>
              
              {activeTab === "leaderboard" ? (
                <>
                  <p className="text-sm text-white/70 mb-4">🏆 {language === "ar" ? "أفضل 4 لاعبين" : "Top 4 Players"}</p>
                  <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                    {goatRecord && (
                      <div className="rounded-2xl bg-gradient-to-r from-yellow-300 via-orange-400 to-red-500 p-[2px]">
                        <div className="rounded-2xl bg-slate-900/90 p-4 text-center">
                          <p className="text-sm text-yellow-200 font-semibold">👑 THE GOAT</p>
                          <p className="text-xl font-black text-white">{goatRecord.name}</p>
                          <p className="text-xs text-white/70">❤️ {goatRecord.lives} • {goatRecord.time}s</p>
                          <p className="text-[10px] text-yellow-400/80 mt-2 italic">
                            {language === "ar" 
                              ? "🐐 الأسطورة الحقيقية... من يستطيع كسر رقمه القياسي؟" 
                              : "🐐 The true legend... who can break this record?"}
                          </p>
                        </div>
                      </div>
                    )}
                    {leaderboard.length === 0 ? (
                      <p className="text-center text-white/50 py-8">{language === "ar" ? "لا يوجد متصدرين بعد" : "No players yet"}</p>
                    ) : (
                      leaderboard.map((entry, index) => {
                        const rankInfo = getRankTitle(index + 1);
                        return (
                          <div
                            key={index}
                            className={`rounded-xl bg-gradient-to-r ${rankInfo.color} p-[2px]`}
                          >
                            <div className="rounded-xl bg-slate-900/90 p-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-2xl">{rankInfo.emoji}</span>
                                  <div>
                                    <p className="font-semibold">{entry.name}</p>
                                    <p className="text-xs text-white/60">{rankInfo.title}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className="text-sm font-semibold">{entry.time}s</p>
                                  <p className="text-xs text-white/60">❤️ {entry.lives}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}</div>
                  <button
                    onClick={() => setPlayerName("")}
                    className="mt-4 w-full rounded-full border border-white/30 px-4 py-2 text-sm transition hover:bg-white/20"
                  >
                    {language === "ar" ? "تغيير الاسم" : "Change Name"}
                  </button>
                </>
              ) : activeTab === "tournament" ? (
                <>
                  <div className="text-center mb-6 p-4 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 rounded-2xl border border-yellow-500/30">
                    <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-orange-400 mb-2">
                      {language === 'ar' ? '🏆 صراع العمالقة نحو لقب THE GOAT' : '🏆 Clash of Titans for THE GOAT'}
                    </h3>
                    <p className="text-yellow-200/80 text-sm italic">
                      {language === 'ar' 
                        ? 'في هذا الدوري، لا مكان إلا للأساطير. الفائز النهائي سيتوج بلقب THE GOAT ويخلد اسمه في قمة لوحة الشرف للأبد.' 
                        : 'In this league, there is only room for legends. The final winner will be crowned THE GOAT and immortalize their name at the top.'}
                    </p>
                  </div>
                  <p className="text-sm text-white/70 mb-4">⚔️ {language === "ar" ? "دوري المتصدرين" : "Tournament"}</p>
                  
                  {!tournamentStarted && leaderboard.length >= 4 && (
                    <div className="mb-6 text-center">
                      <p className="text-yellow-200 mb-2">{language === "ar" ? "🎉 اكتمل عدد اللاعبين (4 لاعبين)!" : "🎉 Players complete (4 players)!"}</p>
                      <button
                        onClick={startTournament}
                        className="w-full rounded-xl bg-gradient-to-r from-green-400 to-emerald-500 p-4 text-slate-900 font-bold text-lg transition hover:scale-[1.02] shadow-lg"
                      >
                        🚀 {language === "ar" ? "ابدأ الدوري الآن!" : "Start Tournament Now!"}
                      </button>
                      <p className="text-xs text-white/60 mt-2">
                        {language === "ar" ? "اضغط لبدء مواجهات الدوري بين أفضل 4 لاعبين" : "Click to start tournament matches between top 4 players"}
                      </p>
                    </div>
                  )}

                  {!tournamentStarted && leaderboard.length < 4 && (
                    <div className="mb-6 text-center">
                      <p className="text-white/70 mb-2">
                        {language === "ar" 
                          ? `⏳ انتظر ${4 - leaderboard.length} لاعبين آخرين ليبدأ الدوري` 
                          : `⏳ Wait for ${4 - leaderboard.length} more players to start tournament`}
                      </p>
                      <div className="rounded-xl bg-white/10 p-4">
                        <p className="text-lg font-semibold text-yellow-300">
                          {language === "ar" ? "اللاعبين المسجلين:" : "Registered Players:"}
                        </p>
                        <div className="space-y-2 mt-2">
                          {leaderboard.map((player, idx) => (
                            <div key={idx} className="flex items-center justify-between bg-white/5 p-2 rounded-lg">
                              <span className="text-sm">{player.name}</span>
                              <span className="text-xs text-white/60">❤️ {player.lives} • {player.time}s</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                    {tournament.length === 0 ? (
                      <p className="text-center text-white/50 py-8">
                        {language === "ar" 
                          ? tournamentStarted 
                            ? "الدوري قيد التشغيل، سيظهر قريباً" 
                            : "يحتاج الدوري إلى 4 لاعبين على الأقل"
                          : tournamentStarted
                          ? "Tournament in progress, will appear soon"
                          : "Need at least 4 players"}
                      </p>
                    ) : (
                      tournament.map((round) => (
                        <div key={round.roundNumber} className="rounded-xl bg-white/5 p-4 border border-white/10">
                          <h3 className="font-bold text-lg mb-3 text-yellow-300">
                            {language === "ar" ? `المرحلة ${round.roundNumber}` : `Round ${round.roundNumber}`} 🏁
                          </h3>
                          <div className="space-y-2">
                            {round.matches.map((match, idx) => (
                              <div key={idx} className="rounded-lg bg-white/10 p-3 text-sm">
                                <div className="flex items-center justify-between">
                                  <div className="flex-1">
                                    <p className={`font-semibold ${match.winner === match.player1 ? "text-green-300" : "text-white/60"}`}>
                                      {match.player1}
                                    </p>
                                    <p className="text-xs text-white/50">
                                      {match.player1Time}s • ❤️ {match.player1Lives}
                                    </p>
                                  </div>
                                  <span className="text-xl mx-2">⚔️</span>
                                  <div className="flex-1 text-right">
                                    <p className={`font-semibold ${match.winner === match.player2 ? "text-green-300" : "text-white/60"}`}>
                                      {match.player2}
                                    </p>
                                    <p className="text-xs text-white/50">
                                      {match.player2Time}s • ❤️ {match.player2Lives}
                                    </p>
                                  </div>
                                </div>
                                {match.winner && (
                                  <p className="text-center text-xs text-green-300 mt-2">
                                    🏆 {language === "ar" ? `الفائز: ${match.winner}` : `Winner: ${match.winner}`}
                                  </p>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </>
              ) : activeTab === "challenge" ? (
                <>
                  <div className="text-center mb-4">
                    <p className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-orange-400">
                      🏆 {language === "ar" ? "الطريق نحو لقب THE GOAT" : "Road to THE GOAT"}
                    </p>
                    <p className="text-xs text-white/60 mt-1">
                      {language === "ar" 
                        ? "اختر صديقك وتحداه. الفائز يقترب خطوة من الأسطورة!" 
                        : "Challenge your friend. Winner gets closer to the legend!"}
                    </p>
                  </div>
                  {!multiplayerRoom ? (
                    <>
                      <div className="space-y-3">
                        <button
                          onClick={() => createRoom("versus")}
                          className="w-full rounded-xl bg-gradient-to-r from-red-400 to-pink-500 p-4 text-slate-900 font-bold text-lg transition hover:scale-[1.02] shadow-lg"
                        >
                          ⚔️ {language === "ar" ? "تحدي صديق" : "Challenge Friend"}
                          <p className="text-sm font-normal mt-1 text-slate-800">{language === "ar" ? "من الأسرع والأذكى؟" : "Who's faster & smarter?"}</p>
                        </button>

                        <div className="mt-6 pt-6 border-t border-white/20">
                          <p className="text-sm text-white/70 mb-3">{language === "ar" ? "الغرف المتاحة:" : "Available Rooms:"}</p>
                          <div className="space-y-2 max-h-[200px] overflow-y-auto">
                            {rooms.filter(r => !r.player2 && r.mode === "versus").length === 0 ? (
                              <p className="text-center text-white/50 text-sm py-4">{language === "ar" ? "لا توجد غرف متاحة" : "No rooms available"}</p>
                            ) : (
                              rooms.filter(r => !r.player2 && r.mode === "versus").map(room => (
                                <div key={room.roomId} className="rounded-lg bg-white/10 p-3 flex items-center justify-between">
                                  <div>
                                    <p className="font-semibold text-sm">{room.player1}</p>
                                    <p className="text-xs text-white/60">⚔️ {language === "ar" ? "منافسة" : "Versus"}</p>
                                  </div>
                                  <button
                                    onClick={() => joinRoom(room.roomId)}
                                    className="rounded-lg bg-gradient-to-r from-cyan-400 to-blue-500 px-4 py-1 text-sm font-bold text-slate-900 transition hover:scale-105"
                                  >
                                    {language === "ar" ? "انضم" : "Join"}
                                  </button>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-white/70">⚔️ {language === "ar" ? "تحدي فردي" : "Versus"}</p>
                        <button
                          onClick={leaveRoom}
                          className="text-xs text-red-400 hover:text-red-300"
                        >
                          ❌ {language === "ar" ? "مغادرة" : "Leave"}
                        </button>
                      </div>

                      <div className="space-y-2 mb-4">
                        <div className="rounded-lg bg-white/10 p-3 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">👤</span>
                            <p className="font-semibold text-sm">{multiplayerRoom.player1}</p>
                          </div>
                          <span className={`text-xs ${multiplayerRoom.player1Ready ? "text-green-400" : "text-white/50"}`}>
                            {multiplayerRoom.player1Ready ? "✅" : "⏳"} {multiplayerRoom.player1Ready ? (language === "ar" ? "جاهز" : "Ready") : (language === "ar" ? "ينتظر" : "Waiting")}
                          </span>
                        </div>
                        
                        {multiplayerRoom.player2 ? (
                          <div className="rounded-lg bg-white/10 p-3 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">👤</span>
                              <p className="font-semibold text-sm">{multiplayerRoom.player2}</p>
                            </div>
                            <span className={`text-xs ${multiplayerRoom.player2Ready ? "text-green-400" : "text-white/50"}`}>
                              {multiplayerRoom.player2Ready ? "✅" : "⏳"} {multiplayerRoom.player2Ready ? (language === "ar" ? "جاهز" : "Ready") : (language === "ar" ? "ينتظر" : "Waiting")}
                            </span>
                          </div>
                        ) : (
                          <div className="rounded-lg bg-white/10 p-3 text-center text-sm text-white/50">
                            ⏳ {language === "ar" ? "في انتظار اللاعب الثاني..." : "Waiting for player 2..."}
                          </div>
                        )}
                      </div>

                      {multiplayerRoom.player2 && multiplayerRoom.status === "waiting" && (
                        <button
                          onClick={toggleReady}
                          className={`w-full rounded-xl p-3 font-bold transition ${
                            (multiplayerRoom.player1 === playerName && multiplayerRoom.player1Ready) ||
                            (multiplayerRoom.player2 === playerName && multiplayerRoom.player2Ready)
                              ? "bg-gradient-to-r from-green-400 to-emerald-500 text-slate-900"
                              : "bg-gradient-to-r from-yellow-400 to-orange-500 text-slate-900"
                          }`}
                        >
                          {(multiplayerRoom.player1 === playerName && multiplayerRoom.player1Ready) ||
                           (multiplayerRoom.player2 === playerName && multiplayerRoom.player2Ready)
                            ? (language === "ar" ? "✅ جاهز - في الانتظار" : "✅ Ready - Waiting")
                            : (language === "ar" ? "🚀 أنا جاهز!" : "🚀 I'm Ready!")}
                        </button>
                      )}
                    </>
                  )}
                  <div className="mt-4 rounded-lg bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-3 border border-yellow-500/30">
                    <p className="text-xs text-center text-yellow-200">
                      {language === "ar" 
                        ? "💡 نصيحة: الفائز في التحديات يحصل على نقاط إضافية تقترب به من لقب THE GOAT!" 
                        : "💡 Tip: Challenge winners earn bonus points toward THE GOAT title!"}
                    </p>
                  </div>
                </>
              ) : null}
            </div>
          </section>
        </main>

        <footer className="text-center mt-10 pb-5">
          <p className="text-white/60 text-sm">
            {language === "ar" ? "تابعنا على" : "Follow us"} <a href="https://instagram.com/_itlulp" target="_blank" rel="noopener noreferrer" className="text-pink-400 hover:text-pink-300 font-semibold">@_itlulp 📱</a>
          </p>
        </footer>
      </div>

      {!playerName && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-sm p-6">
          <div className="w-full max-w-lg rounded-3xl border border-white/20 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8 text-white shadow-2xl">
            <div className="text-center mb-6 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 blur-3xl opacity-30"></div>
              <div className="relative">
                <div className="flex justify-center gap-2 mb-2">
                  <span className="text-4xl animate-bounce" style={{ animationDuration: '1.5s' }}>🏆</span>
                  <span className="text-4xl animate-bounce" style={{ animationDuration: '1.5s', animationDelay: '0.3s' }}>⚔️</span>
                  <span className="text-4xl animate-bounce" style={{ animationDuration: '1.5s', animationDelay: '0.6s' }}>🏆</span>
                </div>
                <h1 className="text-4xl md:text-5xl font-black bg-gradient-to-r from-yellow-200 via-yellow-300 to-orange-400 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(251,191,36,0.8)]" style={{ textShadow: '0 0 50px rgba(251, 191, 36, 0.6)' }}>
                  دوري أبطال Gowin
                </h1>
                <div className="flex items-center justify-center gap-2 mt-2">
                  <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-yellow-400 to-transparent"></div>
                  <p className="text-xs md:text-sm text-white/80 font-semibold">🎮 {language === "ar" ? "ساحة التحدي والمعرفة" : "Arena of Challenge & Knowledge"} 🎮</p>
                  <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-yellow-400 to-transparent"></div>
                </div>
              </div>
            </div>
            <h2 className="text-2xl font-semibold">{language === "ar" ? "أدخل اسمك لبدء التحدي" : "Enter Your Name to Start"}</h2>
            <p className="mt-2 text-white/70">{language === "ar" ? "سيتم حفظ الاسم تلقائياً في الجهاز." : "Your name will be saved automatically."}</p>
            <input
              value={playerInput}
              onChange={(event) => {
                setPlayerInput(event.target.value);
                if (event.target.value.length === 1) {
                  playExciting();
                }
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  handleStart();
                }
              }}
              placeholder={language === "ar" ? "اكتب اسمك هنا" : "Enter your name"}
              className="mt-5 w-full rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-right text-lg focus:border-white/60 focus:outline-none"
              autoFocus
            />
            <button
              onClick={handleStart}
              className="mt-5 w-full rounded-2xl bg-gradient-to-r from-yellow-400 to-orange-500 px-4 py-3 text-lg font-semibold text-slate-900 transition hover:scale-[1.02] shadow-lg"
            >
              🚀 {language === "ar" ? "ابدأ اللعب" : "Start Playing"}
            </button>
          </div>
        </div>
      )}

      {status === "won" && (
        <div className="pointer-events-none fixed inset-0 overflow-hidden">
          {Array.from({ length: 30 }).map((_, index) => (
            <span
              key={index}
              className="confetti"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                backgroundColor: `hsl(${Math.random() * 360}, 90%, 60%)`,
              }}
            />
          ))}
        </div>
      )}

      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-sm p-6">
          <div className="w-full max-w-md rounded-3xl border border-white/20 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8 text-white shadow-2xl">
            <h2 className="text-2xl font-bold mb-4">🔗 {language === "ar" ? "شارك الرابط مع صديقك" : "Share Link with Friend"}</h2>
            <p className="text-white/70 text-sm mb-4">{language === "ar" ? "انسخ هذا الرابط وأرسله لصديقك ليلعب معك" : "Copy and send this link to your friend"}</p>
            <div className="rounded-xl bg-white/10 p-3 mb-4 break-all text-sm">
              {shareLink}
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(shareLink);
                  playExciting();
                }}
                className="flex-1 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 px-4 py-2 font-bold text-slate-900 transition hover:scale-105"
              >
                📋 {language === "ar" ? "نسخ الرابط" : "Copy Link"}
              </button>
              <button
                onClick={() => setShowShareModal(false)}
                className="flex-1 rounded-xl bg-white/10 px-4 py-2 font-semibold transition hover:bg-white/20"
              >
                {language === "ar" ? "إغلاق" : "Close"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* مشغل موسيقى YouTube الخلفية المخفي */}
      {youtubeMusicStarted && (
        <iframe
          id="youtube-background-music"
          title="Background Music"
          width="0"
          height="0"
          src="https://www.youtube.com/embed/jfKfPfyJRdk?autoplay=1&loop=1&playlist=jfKfPfyJRdk&mute=0&controls=0&showinfo=0&modestbranding=1&rel=0&enablejsapi=1"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          style={{
            position: 'absolute',
            top: '-1000px',
            left: '-1000px',
            width: '0',
            height: '0',
            border: 'none',
            opacity: '0',
            pointerEvents: 'none',
            visibility: 'hidden'
          }}
        />
      )}
    </div>
  );
}
